#Chelsea Horton
#4/30/25
#P4LAB1b: Initials
#Use turtle graphics to display your first and last initial

import turtle
win = turtle.Screen()  
t = turtle.Turtle()

t.pensize(10)
t.color('black')
t.shape('turtle')

t.penup()
t.backward(200) 
t.pendown()
t.left(90)
t.forward(150)
t.right(90)
t.forward(100)
t.penup()
t.backward(100)
t.right(90)
t.forward(150)
t.left(90)
t.pendown()
t.forward(100)

t.penup()
t.right(90)
t.forward(100)
t.left(90)
t.forward(50)
t.pendown()

t.left(90)
t.forward(200)
t.penup()
t.backward(100)
t.right(90)
t.pendown()
t.forward(200)
t.left(90)
t.penup()
t.backward(100)
t.pendown()
t.forward(200)

win.mainloop
