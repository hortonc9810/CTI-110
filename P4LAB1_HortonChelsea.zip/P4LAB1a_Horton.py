#Chelsea Horton
#4/930/25
#P4LAB1a:Shapes
#use turtle graphics to draw a square and triangle

import turtle
win= turtle.Screen()
t = turtle.Turtle()

t.pensize(3)           
t.pencolor('purple')   
t.shape('turtle')  

t.forward(300)          
t.left(90)           
t.forward(300)
t.left(90)
t.forward(300)
t.left(90)
t.forward(300)

t.pensize(3)
t.pencolor('green')

t.forward(200)          
t.left(120)            
t.forward(200)
t.left(120)
t.forward(200)

win.mainloop